#!/usr/bin/python
# -*- coding:utf-8 -*-
import smbus
import time

address = 0x20

bus = smbus.SMBus(0)
while True:
    bus.write_byte(address,0x7F&bus.read_byte(address))     #beep on
    bus.write_byte(address,0xEF&bus.read_byte(address))     #led on
    time.sleep(0.5)
    bus.write_byte(address,0x80|bus.read_byte(address))     #beep off
    bus.write_byte(address,0x10|bus.read_byte(address))     #led off
    time.sleep(0.5)
